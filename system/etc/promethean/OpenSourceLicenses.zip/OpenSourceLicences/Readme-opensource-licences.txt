Licenses for open source components used by Promethean Android G series
=======================================================================

---------------------------------------------------------------------------------------------------------------------------

CircularFloatingActionMenu
~~~~~~~~~~~~~~~~~~~~~~~~~~
Copyright (c) 2014 Oğuz Bilgener
The circular floating action menu component used in this library and app is based on the MIT licensed component :-

https://github.com/oguzbilgener/CircularFloatingActionMenu

A copy of the MIT license is included.


Licence

CircularFloatingActionMenu is released under MIT Licence. See file LICENCE-MIT.txt.

---------------------------------------------------------------------------------------------------------------------------

Impression (A material design gallery app for Android 4.1+)
~~~~~~~~~~
Copyright (C) 2015  Aidan Follestad, Daniel Ciao, and Marlon Jones
The Impression app is licensed under the GPL V3 license.

https://github.com/afollestad/impression

A copy of the GPL V3 license is included.

License

Impression: A material design gallery app for Android 4.1+
Copyright (C) 2015  Aidan Follestad, Daniel Ciao, and Marlon Jones

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

---------------------------------------------------------------------------------------------------------------------------