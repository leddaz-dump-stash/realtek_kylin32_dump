#!/system/bin/sh

rm /mnt/sdcard/googleservice/success

echo "Google Installer : Version 1.1.0"
echo "start to remove Google apps & service ..."

/system/bin/mount -o remount /system

sleep 1

rm -rf /system/priv-app/Phonesky

sync
/system/bin/mount -o remount,ro /system

# remove google mobile service file & data
rm -rf /data/app/com.android.vending*

# clear flag
rm /data/etc/ginstalled

# setup success flag
touch /mnt/sdcard/googleservice/success
chmod 0755 /mnt/sdcard/googleservice/success

sync

echo "Remove Google apps & services done!"

exit 0

