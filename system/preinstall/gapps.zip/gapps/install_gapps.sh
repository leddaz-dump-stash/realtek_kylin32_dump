#!/system/bin/sh

rm /mnt/sdcard/googleservice/success

echo "Google Installer : Version 1.1.0"
echo "Start to install Google apps & services ..."

SOURCE_ROOT=/mnt/sdcard/googleservice/gapps

/system/bin/mount -o remount /system

sleep 1

# priv app
mkdir -p /system/priv-app/Phonesky
chmod 0755 /system/priv-app/Phonesky
cp -f $SOURCE_ROOT/system/priv-app/Phonesky/Phonesky.apk /system/priv-app/Phonesky/Phonesky.apk
chmod 0644 /system/priv-app/Phonesky/Phonesky.apk

sync
/system/bin/mount -o remount,ro /system

# setup user installed flag
touch /data/etc/ginstalled
chmod 0744 /data/etc/ginstalled

# setup success flag
touch /mnt/sdcard/googleservice/success
chmod 0755 /mnt/sdcard/googleservice/success

sync

echo "Install Google apps & services done!"

exit 0

